<?php
/*
Plugin Name: sn VIP & File Download
Plugin URI: http://sn
Description: افزونه فروشگاه فایل دانلود در ازای پرداخت وجوه و اشتراک ویژه
Version: 1.2
Author: sn
Author URI: http://
*/

include_once('sn_func.php');